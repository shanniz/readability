ALTER TABLE xwnparselfts DROP FOREIGN KEY fk_xwnparselfts_synsetid;
ALTER TABLE xwnwsds DROP FOREIGN KEY fk_xwnwsds_synsetid;
ALTER TABLE xwnparselfts DROP INDEX k_xwnparselfts_synsetid;
ALTER TABLE xwnparselfts DROP INDEX k_xwnparselfts_synsetid_parse_lft;
ALTER TABLE xwnwsds DROP INDEX k_xwnwsds_synsetid;
ALTER TABLE xwnwsds DROP INDEX k_xwnwsds_synsetid_wsd_text;
