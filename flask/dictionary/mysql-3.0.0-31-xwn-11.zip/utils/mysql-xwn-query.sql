SELECT 'XWORDNET' AS section;

SELECT 'get xwordnet parses for verb "want"' AS comment;
SELECT lemma,synsetid,definition,parse
FROM words
LEFT JOIN senses USING (wordid)
INNER JOIN synsets USING (synsetid)
INNER JOIN xwnparselfts USING (synsetid)
WHERE pos='v' and lemma='want';

SELECT 'get xwordnet lft for verb "want"' AS comment;
SELECT lemma,synsetid,definition,lft
FROM words
LEFT JOIN senses USING (wordid)
INNER JOIN synsets USING (synsetid)
INNER JOIN xwnparselfts USING (synsetid)
WHERE pos='v' and lemma='want';

SELECT 'get xwordnet wsd for verb "want"' AS comment;
SELECT lemma,synsetid,definition,wsd
FROM words
LEFT JOIN senses USING (wordid)
INNER JOIN synsets USING (synsetid)
INNER JOIN xwnwsds USING (synsetid)
WHERE pos='v' and lemma='want';

