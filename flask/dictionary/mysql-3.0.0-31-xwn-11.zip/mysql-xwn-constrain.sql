ALTER TABLE xwnparselfts ADD INDEX k_xwnparselfts_synsetid (synsetid);
ALTER TABLE xwnparselfts ADD INDEX k_xwnparselfts_synsetid_parse_lft (synsetid,parse (100),lft (100));
ALTER TABLE xwnwsds ADD INDEX k_xwnwsds_synsetid (synsetid);
ALTER TABLE xwnwsds ADD INDEX k_xwnwsds_synsetid_wsd_text (synsetid,wsd (128),`text` (128));
ALTER TABLE xwnparselfts ADD CONSTRAINT fk_xwnparselfts_synsetid FOREIGN KEY k_xwnparselfts_synsetid (synsetid) REFERENCES synsets (synsetid);
ALTER TABLE xwnwsds ADD CONSTRAINT fk_xwnwsds_synsetid FOREIGN KEY k_xwnwsds_synsetid (synsetid) REFERENCES synsets (synsetid);
